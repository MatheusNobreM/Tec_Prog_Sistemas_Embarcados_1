#ifndef FUNCAO02_H
#define FUNCAO02_H

int funcao02(int a, int b);

#endif