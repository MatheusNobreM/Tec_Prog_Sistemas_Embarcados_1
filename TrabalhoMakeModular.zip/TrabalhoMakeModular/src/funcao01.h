#ifndef FUNCAO01_H
#define FUNCAO01_H

int funcao01(int a, int b);

#endif