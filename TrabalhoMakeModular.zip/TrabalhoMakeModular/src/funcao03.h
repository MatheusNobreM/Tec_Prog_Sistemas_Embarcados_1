#ifndef FUNCAO03_H
#define FUNCAO03_H

int funcao03(int a, int b);

#endif