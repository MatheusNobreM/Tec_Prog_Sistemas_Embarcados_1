#ifndef IMPRIME_H
#define IMPRIME_H

void imprime(const char *desenvolvedor);

#endif