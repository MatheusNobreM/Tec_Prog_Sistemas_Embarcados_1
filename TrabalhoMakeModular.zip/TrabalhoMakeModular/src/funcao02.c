#include "funcao02.h"

int funcao02(int a, int b) {
    return a - b;
}