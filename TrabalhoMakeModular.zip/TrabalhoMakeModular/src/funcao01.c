#include "funcao01.h"

int funcao01(int a, int b) {
    return a + b;
}