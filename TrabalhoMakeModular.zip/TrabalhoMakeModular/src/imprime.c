#include <stdio.h>
#include "imprime.h"

void imprime(const char *desenvolvedor) {
    printf("******************************\n");
    printf("* LINGUAGEM C *\n");
    printf("******************************\n");
    printf("Desenvolvedor: %s\n", desenvolvedor);
}