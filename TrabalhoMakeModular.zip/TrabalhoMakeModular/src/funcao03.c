#include "funcao03.h"

int funcao03(int a, int b) {
    return a * b;
}